from datetime import datetime
import time
import os

from colorama import Fore, Style, init

from modules import bell
from modules import menu
from modules import bluetooth
from modules import addschedule
from modules import logs


init(autoreset=True)


# ============================================================
# LOGGING HELPER
# ============================================================

def save_log(message):
    """
    Send log message to modules.logs without changing
    the existing project concept.

    Supports common function names from logs.py.
    """

    try:

        # Most common function names
        log_functions = (
            "add_log",
            "save_log",
            "write_log",
            "log_event",
            "log",
            "record_log",
        )

        for function_name in log_functions:

            log_function = getattr(logs, function_name, None)

            if callable(log_function):

                try:
                    log_function(message)
                    return True

                except TypeError:

                    # Some logging functions may expect
                    # date/time + message separately.
                    try:
                        log_function(
                            datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                            message
                        )
                        return True

                    except Exception:
                        pass

        # --------------------------------------------------------
        # FALLBACK
        # --------------------------------------------------------
        # If logs.py does not expose a known function,
        # create a simple text log beside the project.
        #
        # This does NOT affect the existing system flow.
        # --------------------------------------------------------

        log_file = "system_logs.txt"

        timestamp = datetime.now().strftime(
            "%Y-%m-%d %H:%M:%S"
        )

        with open(
            log_file,
            "a",
            encoding="utf-8"
        ) as file:

            file.write(
                f"[{timestamp}] {message}\n"
            )

        return True

    except Exception:
        # Logging must never stop the main program.
        return False


# ============================================================
# MAIN
# ============================================================

def main():

    # ========================================================
    # BANNER
    # ========================================================

    def banner():

        art = r"""
        ███████╗ ██████╗██╗  ██╗███████╗██████╗ ██╗   ██╗██╗     ███████╗
        ██╔════╝██╔════╝██║  ██║██╔════╝██╔══██╗██║   ██║██║     ██╔════╝
        ███████╗██║     ███████║█████╗  ██║  ██║██║   ██║██║     ███████╗
        ╚════██║██║     ██╔══██║██╔══╝  ██║  ██║██║   ██║██║     ╚════██║
        ███████║╚██████╗██║  ██║███████╗██████╔╝╚██████╔╝███████╗███████║
        ╚══════╝ ╚═════╝╚═╝  ╚═╝╚══════╝╚═════╝  ╚═════╝ ╚══════╝╚══════╝
        """

        try:
            terminal_width = os.get_terminal_size().columns

        except OSError:
            terminal_width = 80

        for line in art.strip("\n").splitlines():

            padding = max(
                0,
                (terminal_width - len(line)) // 2
            )

            print(
                " " * padding
                + Fore.MAGENTA
                + line
                + Style.RESET_ALL
            )

        print(
            Fore.YELLOW
            + "--------------------------------------------------------|".center(
                terminal_width
            )
        )

        print(
            Fore.CYAN
            + "|                    [ SCHEDULE - SYS ]                 |".center(
                terminal_width
            )
        )

        print(
            Fore.GREEN
            + "|                 >>> SYSTEM is READY <<<               |".center(
                terminal_width
            )
        )

        print(
            Fore.YELLOW
            + "|-------------------------------------------------------|".center(
                terminal_width
            )
        )


    # ========================================================
    # INFO
    # ========================================================

    def info():

        print(
            Fore.BLACK
            + "================================================="
        )

        print(
            Fore.BLACK
            + "|                                                 |"
        )

        print(
            Fore.MAGENTA
            + "        [+]-START THE SCHEDULE SYS               "
        )

        print(
            Fore.RED
            + "                  -if start the sys [Y/N]        "
        )

        print(
            Fore.BLACK
            + "|                                                 |"
        )

        print(
            Fore.BLACK
            + "================================================="
        )


    # ========================================================
    # START SCREEN
    # ========================================================

    banner()

    time.sleep(2)

    print(
        Fore.RED
        + "╔═══════════════╗".center(50)
    )

    print(
        Fore.WHITE
        + "[ 🖥️ - SYS -info ]".center(50)
    )

    print(
        Fore.RED
        + "╚═══════════════╝".center(50)
    )

    print(
        Fore.GREEN
        + " |".center(50)
    )

    print(
        Fore.GREEN
        + " |".center(50)
    )

    print(
        Fore.GREEN
        + " |".center(50)
    )

    print(
        Fore.GREEN
        + "_________________".center(50)
    )

    print(
        Fore.GREEN
        + "|               |".center(50)
    )

    info()


    # ========================================================
    # OPTIONS
    # ========================================================

    yes = Fore.GREEN + "Y"
    no = Fore.RED + "N"
    syb = Fore.GREEN + "●"


    # ========================================================
    # START SYSTEM
    # ========================================================

    while True:

        try:

            ask = input(
                Fore.WHITE
                + "[ SYS ] START SCHEDULE-SYS? ["
                + yes
                + Fore.WHITE
                + "/"
                + no
                + Fore.WHITE
                + "]: "
            ).strip().lower()

        except KeyboardInterrupt:

            print(
                Fore.YELLOW
                + "\n\n[ SYS ] SYSTEM STOPPED."
                + Style.RESET_ALL
            )

            save_log("SYSTEM STOPPED - KeyboardInterrupt")

            return


        # ====================================================
        # START
        # ====================================================

        if ask in ("y", "yes"):

            # ------------------------------------------------
            # LOG: SYSTEM START
            # ------------------------------------------------

            save_log("SCHEDULE SYSTEM STARTED")

            time.sleep(2)

            print(
                Fore.WHITE
                + "[ SYS ] is STARTING NOW..."
            )

            print(
                Fore.WHITE
                + "[ SYS ] LOADING..."
            )

            print(
                "+>",
                syb
                + Fore.GREEN
                + " MENU - ONLINE"
            )

            print(
                "+>",
                syb
                + Fore.RED
                + " BLUETOOTH - OFFLINE"
            )

            save_log("MENU STATUS: ONLINE")
            save_log("BLUETOOTH STATUS: OFFLINE")

            time.sleep(2)


            # =================================================
            # BLUETOOTH CONNECTION LOOP
            # =================================================

            while True:

                try:

                    bluetooth_choice = input(
                        Fore.WHITE
                        + "[ SYS ] CONNECT BLUETOOTH ? ["
                        + yes
                        + Fore.WHITE
                        + "/"
                        + no
                        + Fore.WHITE
                        + "]: "
                    ).strip().lower()

                except KeyboardInterrupt:

                    print(
                        Fore.YELLOW
                        + "\n\n[ SYS ] SYSTEM STOPPED."
                        + Style.RESET_ALL
                    )

                    save_log(
                        "SYSTEM STOPPED - KeyboardInterrupt during Bluetooth selection"
                    )

                    return


                # =============================================
                # NO
                # =============================================

                if bluetooth_choice in ("n", "no"):

                    print(
                        Fore.YELLOW
                        + "\n[ BT ] Bluetooth connection skipped."
                        + Style.RESET_ALL
                    )

                    save_log(
                        "BLUETOOTH CONNECTION SKIPPED BY USER"
                    )

                    time.sleep(3)

                    # -----------------------------------------
                    # NO BLUETOOTH = MENU ALLOWED
                    # -----------------------------------------

                    break


                # =============================================
                # YES
                # =============================================

                elif bluetooth_choice in ("y", "yes"):

                    print(
                        Fore.CYAN
                        + "\n[ BT ] Searching for Bluetooth devices..."
                        + Style.RESET_ALL
                    )

                    save_log(
                        "BLUETOOTH SEARCH STARTED"
                    )

                    time.sleep(2)

                    os.system("cls")


                    # -----------------------------------------
                    # START BLUETOOTH
                    # -----------------------------------------

                    bluetooth_status = bluetooth.start_bluetooth()


                    # =========================================
                    # BLUETOOTH SUCCESS
                    # =========================================

                    if bluetooth_status is True:

                        print(
                            Fore.GREEN
                            + "\n[ SYS ] BLUETOOTH - ONLINE ●"
                            + Style.RESET_ALL
                        )

                        print(
                            Fore.GREEN
                            + "[ SYS ] Bluetooth connection successful."
                            + Style.RESET_ALL
                        )

                        save_log(
                            "BLUETOOTH CONNECTION SUCCESSFUL - ONLINE"
                        )

                        time.sleep(1)

                        # -------------------------------------
                        # ONLY NOW MENU IS ALLOWED
                        # -------------------------------------

                        break


                    # =========================================
                    # BLUETOOTH FAILED / CTRL+C / STOPPED
                    # =========================================

                    else:

                        print(
                            Fore.RED
                            + "\n[ SYS ] BLUETOOTH - OFFLINE ●"
                            + Style.RESET_ALL
                        )

                        print(
                            Fore.YELLOW
                            + "[ SYS ] Bluetooth must be connected."
                            + Style.RESET_ALL
                        )

                        save_log(
                            "BLUETOOTH CONNECTION FAILED - OFFLINE"
                        )

                        print(
                            Fore.CYAN
                            + "\n[ SYS ] Returning to Bluetooth connection..."
                            + Style.RESET_ALL
                        )

                        time.sleep(2)

                        os.system("cls")

                        # -------------------------------------
                        # DO NOT GO TO MENU
                        # ASK AGAIN
                        # -------------------------------------

                        continue


                # =============================================
                # INVALID
                # =============================================

                else:

                    print(
                        Fore.RED
                        + "\n[ SYS ] Please enter a correct option [Y/N]."
                        + Style.RESET_ALL
                    )

                    save_log(
                        "INVALID BLUETOOTH INPUT"
                    )

                    continue


            # =================================================
            # MENU
            # =================================================
            #
            # Reaching here means:
            #
            # 1. User selected NO
            # OR
            # 2. Bluetooth successfully became ONLINE
            #
            # =================================================

            save_log(
                "MAIN MENU ACCESS GRANTED"
            )

            time.sleep(1)

            os.system("cls")

            menu.menu_info()

            save_log(
                "MENU DISPLAYED"
            )

            menu.choose()

            save_log(
                "MENU SESSION ENDED"
            )

            break


        # ====================================================
        # SYSTEM OFF
        # ====================================================

        elif ask in ("n", "no"):

            print(
                Fore.RED
                + "[ SYS ] SYSTEM OFF"
                + Style.RESET_ALL
            )

            save_log(
                "SCHEDULE SYSTEM TURNED OFF BY USER"
            )

            break


        # ====================================================
        # INVALID START OPTION
        # ====================================================

        else:

            print(
                Fore.RED
                + "[ SYS ] Please enter a correct option [Y/N]"
                + Style.RESET_ALL
            )

            save_log(
                "INVALID SYSTEM START INPUT"
            )


# ============================================================
# RUN
# ============================================================

if __name__ == "__main__":

    main()