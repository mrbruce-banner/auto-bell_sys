from datetime import datetime
import json
import os
from colorama import Style, Fore, init
from modules import menu
import time


init()


# ============================================================
# PROJECT PATH
# ============================================================

BASE_DIR = os.path.dirname(
    os.path.dirname(
        os.path.abspath(__file__)
    )
)

SCHEDULE_FILE = os.path.join(
    BASE_DIR,
    "cookies",
    "schedules.json"
)


def add_schedule():

    print(Fore.MAGENTA + "\n╭────────────────────────────────────╮")
    print(Fore.CYAN + "│          ADD SCHEDULE              │")
    print(Fore.RED + "|              [+] exit              |")
    print("╰────────────────────────────────────╯")
    print(Style.RESET_ALL)


    # Schedule name
    while True:

        name = input(
            Fore.WHITE + "❯ Schedule Name : "
        ).strip()

        print(Style.RESET_ALL)


        if name.lower() == "exit":

            print(
                Fore.RED
                + "[-] SCHEDULE ADD FUN IS EXIT "
            )

            print(Style.RESET_ALL)

            time.sleep(2)

            os.system("cls")

            menu.menu_info()

            menu.choose()

            break


        elif name:

            break


        else:

            print(
                "❌ Schedule name cannot be empty."
            )


    # Time
    while True:

        time_input = input(
            Fore.WHITE
            + "❯ Schedule Time (HH:MM AM/PM): "
        ).strip()


        try:

            schedule_time = datetime.strptime(
                time_input,
                "%I:%M %p"
            ).strftime("%I:%M %p")

            break


        except ValueError:

            print(
                "❌ Invalid time. Example: 09:30 AM"
            )


    # Repeat
    print(Fore.WHITE + "\n❯ Repeat Type")

    print(
        Fore.GREEN
        + "   [ 01 ] ONCE"
    )

    print(
        Fore.GREEN
        + "   [ 02 ] DAILY"
    )

    print(
        Fore.GREEN
        + "   [ 03 ] WEEKLY"
    )


    while True:

        repeat = input(
            Fore.YELLOW + "❯ Choose : "
        ).strip()

        print(Style.RESET_ALL)


        if repeat == "1":

            repeat_type = "ONCE"

            break


        elif repeat == "2":

            repeat_type = "DAILY"

            break


        elif repeat == "3":

            repeat_type = "WEEKLY"

            break


        else:

            print(
                "❌ Choose 1, 2 or 3."
            )


    # Status
    print(
        Fore.WHITE
        + "\n❯ Schedule Status"
    )

    print(
        Fore.GREEN
        + "   [ 01 ] ENABLED"
    )

    print(
        Fore.RED
        + "   [ 02 ] DISABLED"
    )


    while True:

        status = input(
            Fore.YELLOW + "❯ Choose : "
        ).strip()

        print(Style.RESET_ALL)


        if status == "1":

            schedule_status = "ENABLED"

            break


        elif status == "2":

            schedule_status = "DISABLED"

            break


        else:

            print(
                "❌ Choose 1 or 2."
            )


    # Create schedule
    schedule = {
        "name": name,
        "time": schedule_time,
        "repeat": repeat_type,
        "bell": "bell.wav",
        "status": schedule_status
    }


    # Load existing schedules
    schedules = []


    if os.path.exists(SCHEDULE_FILE):

        with open(
            SCHEDULE_FILE,
            "r"
        ) as file:

            try:

                schedules = json.load(file)

            except json.JSONDecodeError:

                schedules = []


    # Add new schedule
    schedules.append(schedule)


    # Save
    with open(
        SCHEDULE_FILE,
        "w"
    ) as file:

        json.dump(
            schedules,
            file,
            indent=4
        )


    print(
        Fore.WHITE
        + "\n╭────────────────────────────────────╮"
    )

    print(
        Fore.WHITE
        + "│      ✓ SCHEDULE ADDED              │"
    )

    print(
        Fore.GREEN
        + "|               -successfully        |"
    )

    print(
        Fore.WHITE
        + "╰────────────────────────────────────╯"
    )


    print(
        Fore.RED
        + f"  NAME   : {name}"
    )

    print(
        Fore.WHITE
        + f"  TIME   : {schedule_time}"
    )

    print(
        Fore.WHITE
        + f"  REPEAT : {repeat_type}"
    )

    print(
        Fore.RED
        + "  BELL   : FIXED BELL"
    )

    print(
        Fore.WHITE
        + f"  STATUS : {schedule_status}"
    )


    time.sleep(2)

    qn = input(
        Fore.GREEN
        + "press enter to continue menu ......"
    )

    time.sleep(2)

    os.system("cls")

    menu.menu_info()

    menu.choose()


if __name__ == "__main__":

    add_schedule()