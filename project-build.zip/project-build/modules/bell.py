import pygame
import time


def bell_fun():
    pygame.mixer.init()
    pygame.mixer.music.load("sch-bell.mp3")
    pygame.mixer.music.play()
    time.sleep(10)
    pygame.mixer.music.stop()

if __name__ =="__main__":

    bell_fun()