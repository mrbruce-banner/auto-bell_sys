import asyncio
import os

from colorama import Fore, Style, init

from winrt.windows.devices.bluetooth import (
    BluetoothAdapter,
    BluetoothDevice,
    BluetoothMajorClass,
)

from winrt.windows.devices.enumeration import DeviceInformation
from winrt.windows.devices.radios import Radio, RadioState


init(autoreset=True)


# ============================================================
# CLEAR SCREEN
# ============================================================

def clear():
    os.system("cls")


# ============================================================
# BANNER
# ============================================================

def banner():

    print(
        Fore.MAGENTA
        + r"""
██████╗ ██╗     ██╗   ██╗███████╗████████╗ ██████╗  ██████╗ ████████╗██╗  ██╗
██╔══██╗██║     ██║   ██║██╔════╝╚══██╔══╝██╔═══██╗██╔═══██╗╚══██╔══╝██║  ██║
██████╔╝██║     ██║   ██║█████╗     ██║   ██║   ██║██║   ██║   ██║   ███████║
██╔══██╗██║     ██║   ██║██╔══╝     ██║   ██║   ██║██║   ██║   ██║   ██╔══██║
██████╔╝███████╗╚██████╔╝███████╗   ██║   ╚██████╔╝╚██████╔╝   ██║   ██║  ██║
╚═════╝ ╚══════╝╚═════╝ ╚══════╝   ╚═╝    ╚═════╝  ╚═════╝    ╚═╝   ╚═╝  ╚═╝

                 [ BLUETOOTH - SYS ]
"""
        + Style.RESET_ALL
    )


# ============================================================
# GET BLUETOOTH ADAPTER
# ============================================================

async def get_bluetooth_adapter():

    return await BluetoothAdapter.get_default_async()


# ============================================================
# GET BLUETOOTH STATUS
# ============================================================

async def get_bluetooth_status():

    adapter = await get_bluetooth_adapter()

    if adapter is None:
        return None

    radio = await adapter.get_radio_async()

    if radio is None:
        return None

    return radio.state


# ============================================================
# TURN ON BLUETOOTH
# ============================================================

async def turn_on_bluetooth():

    access = await Radio.request_access_async()

    if str(access).lower().endswith("denied"):
        return False

    adapter = await get_bluetooth_adapter()

    if adapter is None:
        return False

    radio = await adapter.get_radio_async()

    if radio is None:
        return False

    await radio.set_state_async(
        RadioState.ON
    )

    return (
        await get_bluetooth_status()
    ) == RadioState.ON


# ============================================================
# SCAN BLUETOOTH DEVICES
# ============================================================

async def show_bluetooth_devices():

    discovered_devices = (
        await DeviceInformation.find_all_async_aqs_filter(
            BluetoothDevice.get_device_selector()
        )
    )

    devices = []

    for device in discovered_devices:

        try:

            bluetooth_device = (
                await BluetoothDevice.from_id_async(
                    device.id
                )
            )

            if (
                bluetooth_device is not None
                and bluetooth_device.class_of_device is not None
                and bluetooth_device.class_of_device.major_class
                == BluetoothMajorClass.AUDIO_VIDEO
            ):
                devices.append(device)

        except Exception:

            continue

    return devices


# ============================================================
# PAIR BLUETOOTH DEVICE
# ============================================================

async def pair_bluetooth_device(device):

    if device.pairing.is_paired:

        return True, "Device is already paired."

    result = await device.pairing.pair_async()

    status = str(result.status)

    return (
        status.upper().endswith("PAIRED"),
        status
    )


# ============================================================
# BLUETOOTH SYSTEM
# ============================================================

async def bluetooth_system():

    while True:

        # ====================================================
        # CLEAN SCREEN
        # ====================================================

        clear()
        banner()

        # ====================================================
        # CHECK BLUETOOTH
        # ====================================================

        print(
            Fore.CYAN
            + "\n[ BT ] Checking system Bluetooth..."
            + Style.RESET_ALL
        )

        try:

            state = await get_bluetooth_status()

        except Exception as error:

            print(
                Fore.RED
                + f"\n[ BT ] Bluetooth check failed : {error}"
                + Style.RESET_ALL
            )

            input(
                Fore.WHITE
                + "\nPress ENTER to try Bluetooth again..."
            )

            continue

        # ====================================================
        # ADAPTER NOT FOUND
        # ====================================================

        if state is None:

            print(
                Fore.RED
                + "\n[ BT ] Bluetooth adapter not found."
                + Style.RESET_ALL
            )

            print(
                Fore.YELLOW
                + "[ BT ] Please make sure your laptop has Bluetooth."
                + Style.RESET_ALL
            )

            input(
                Fore.WHITE
                + "\nPress ENTER to try Bluetooth again..."
            )

            continue

        # ====================================================
        # BLUETOOTH ON
        # ====================================================

        if state == RadioState.ON:

            print(
                Fore.GREEN
                + "\n[ BT ] SYSTEM BLUETOOTH : ON ●"
                + Style.RESET_ALL
            )

        # ====================================================
        # BLUETOOTH OFF
        # ====================================================

        else:

            print(
                Fore.RED
                + "\n[ BT ] SYSTEM BLUETOOTH : OFF ●"
                + Style.RESET_ALL
            )

            print(
                Fore.YELLOW
                + "\n[ BT ] Bluetooth is turned OFF."
                + Style.RESET_ALL
            )

            ask = input(
                Fore.WHITE
                + "\n[ BT ] Turn ON Bluetooth in this terminal? [Y/N] : "
            ).strip().lower()

            # ------------------------------------------------
            # USER SAYS NO
            # ------------------------------------------------

            if ask not in ("y", "yes"):

                print(
                    Fore.YELLOW
                    + "\n[ BT ] Bluetooth setup skipped."
                    + Style.RESET_ALL
                )

                input(
                    Fore.WHITE
                    + "\nPress ENTER to try Bluetooth again..."
                )

                continue

            # ------------------------------------------------
            # TRY TO TURN ON
            # ------------------------------------------------

            try:

                if not await turn_on_bluetooth():

                    raise RuntimeError(
                        "Windows denied radio control"
                    )

            except Exception as error:

                print(
                    Fore.RED
                    + "\n[ BT ] Could not turn Bluetooth on automatically:"
                    + Style.RESET_ALL
                )

                print(
                    Fore.RED
                    + f"[ BT ] {error}"
                    + Style.RESET_ALL
                )

                print(
                    Fore.YELLOW
                    + "\n[ BT ] Opening Windows Bluetooth Settings..."
                    + Style.RESET_ALL
                )

                os.system(
                    "start ms-settings:bluetooth"
                )

                input(
                    Fore.WHITE
                    + "\n[ BT ] Turn Bluetooth ON, then press ENTER..."
                )

            # ------------------------------------------------
            # CHECK AGAIN
            # ------------------------------------------------

            try:

                state = await get_bluetooth_status()

            except Exception as error:

                print(
                    Fore.RED
                    + f"\n[ BT ] Bluetooth status check failed : {error}"
                    + Style.RESET_ALL
                )

                input(
                    Fore.WHITE
                    + "\nPress ENTER to try Bluetooth again..."
                )

                continue

            # ------------------------------------------------
            # STILL OFF
            # ------------------------------------------------

            if state != RadioState.ON:

                print(
                    Fore.RED
                    + "\n[ BT ] Bluetooth is still OFF."
                    + Style.RESET_ALL
                )

                input(
                    Fore.WHITE
                    + "\nPress ENTER to try Bluetooth again..."
                )

                continue

            print(
                Fore.GREEN
                + "\n[ BT ] SYSTEM BLUETOOTH : ON ●"
                + Style.RESET_ALL
            )

        # ====================================================
        # DEVICE SCANNING
        # ====================================================

        print(
            Fore.CYAN
            + "\n[ BT ] Scanning for Bluetooth devices..."
            + Style.RESET_ALL
        )

        try:

            devices = await show_bluetooth_devices()

        except Exception as error:

            print(
                Fore.RED
                + f"\n[ BT ] Device scan failed : {error}"
                + Style.RESET_ALL
            )

            input(
                Fore.WHITE
                + "\nPress ENTER to scan again..."
            )

            continue

        # ====================================================
        # FILTER DEVICES
        # ====================================================

        visible_devices = []

        for device in devices:

            try:

                name = device.name.strip()

            except Exception:

                continue

            if not name:
                continue

            visible_devices.append(device)

        # ====================================================
        # NO DEVICES FOUND
        # ====================================================

        if not visible_devices:

            print(
                Fore.YELLOW
                + "\n[ BT ] No Bluetooth devices found."
                + Style.RESET_ALL
            )

            print(
                Fore.CYAN
                + "\n[ BT ] Please turn ON your Bluetooth speaker/device."
                + Style.RESET_ALL
            )

            print(
                Fore.WHITE
                + "\n[ BT ] Bluetooth screen will restart."
                + Style.RESET_ALL
            )

            input(
                Fore.WHITE
                + "\nPress ENTER to try again..."
            )

            continue

        # ====================================================
        # AVAILABLE DEVICES
        # ====================================================

        clear()
        banner()

        print(
            Fore.GREEN
            + "\n[ BT ] SYSTEM BLUETOOTH : ON ●"
            + Style.RESET_ALL
        )

        print(
            Fore.CYAN
            + "\n╭────────────────────────────────────────────────────────────╮"
            + Style.RESET_ALL
        )

        print(
            Fore.CYAN
            + "│                 AVAILABLE BLUETOOTH DEVICES                │"
            + Style.RESET_ALL
        )

        print(
            Fore.CYAN
            + "├────────────────────────────────────────────────────────────┤"
            + Style.RESET_ALL
        )

        for index, device in enumerate(
            visible_devices,
            start=1
        ):

            print(
                Fore.WHITE
                + f"│  [{index:02d}] "
                + Fore.GREEN
                + f"{device.name:<45}"
                + Fore.WHITE
                + "│"
                + Style.RESET_ALL
            )

        print(
            Fore.CYAN
            + "╰────────────────────────────────────────────────────────────╯"
            + Style.RESET_ALL
        )

        # ====================================================
        # SELECT DEVICE
        # ====================================================

        choice = input(
            Fore.WHITE
            + "\n❯ Select Bluetooth Device [ID] : "
        ).strip()

        # ====================================================
        # INVALID INPUT
        # ====================================================

        if not choice.isdigit():

            print(
                Fore.RED
                + "\n❌ Enter a valid device ID."
                + Style.RESET_ALL
            )

            input(
                Fore.WHITE
                + "\nPress ENTER to try again..."
            )

            continue

        index = int(choice) - 1

        # ====================================================
        # INVALID DEVICE ID
        # ====================================================

        if index < 0 or index >= len(visible_devices):

            print(
                Fore.RED
                + "\n❌ Device ID not found."
                + Style.RESET_ALL
            )

            input(
                Fore.WHITE
                + "\nPress ENTER to try again..."
            )

            continue

        selected = visible_devices[index]

        # ====================================================
        # SELECTED DEVICE
        # ====================================================

        print(
            Fore.CYAN
            + f"\n[ BT ] Selected : {selected.name}"
            + Style.RESET_ALL
        )

        print(
            Fore.GREEN
            + f"\n[ BT ] Device : {selected.name}"
            + Style.RESET_ALL
        )

        # ====================================================
        # PAIR DEVICE
        # ====================================================

        try:

            paired, status = (
                await pair_bluetooth_device(
                    selected
                )
            )

        except Exception as error:

            paired = False
            status = str(error)

        # ====================================================
        # PAIR SUCCESS
        # ====================================================

        if paired:

            print(
                Fore.GREEN
                + f"\n[ BT ] Pairing completed: {status}"
                + Style.RESET_ALL
            )

            print(
                Fore.CYAN
                + "[ BT ] Windows will manage the device connection."
                + Style.RESET_ALL
            )

            input(
                Fore.WHITE
                + "\nPress ENTER to continue..."
            )

            continue

        # ====================================================
        # PAIRING FAILED
        # ====================================================

        print(
            Fore.RED
            + f"\n[ BT ] Pairing failed: {status}"
            + Style.RESET_ALL
        )

        input(
            Fore.WHITE
            + "\nPress ENTER to try Bluetooth again..."
        )

        continue


# ============================================================
# START BLUETOOTH
# ============================================================

def start_bluetooth():

    try:

        asyncio.run(
            bluetooth_system()
        )

        return True

    except KeyboardInterrupt:

        print(
            Fore.YELLOW
            + "\n\n[ BT ] Bluetooth stopped."
            + Style.RESET_ALL
        )

        print(
            Fore.CYAN
            + "[ BT ] Returning to main system..."
            + Style.RESET_ALL
        )

        return False

    except Exception as error:

        print(
            Fore.RED
            + f"\n[ BT ] Unexpected error : {error}"
            + Style.RESET_ALL
        )

        return False


# ============================================================
# RUN DIRECTLY
# ============================================================

if __name__ == "__main__":

    start_bluetooth()