import json
import os
from colorama import Style, Fore, init
from modules import menu
import time


init()


# ============================================================
# JSON FILE PATHS
# ============================================================

BASE_DIR = os.path.dirname(
    os.path.dirname(
        os.path.abspath(__file__)
    )
)

COOKIES_DIR = os.path.join(
    BASE_DIR,
    "cookies"
)


SCHEDULE_FILE = os.path.join(
    COOKIES_DIR,
    "schedules.json"
)


SCHOOL_SCHEDULE_FILE = os.path.join(
    COOKIES_DIR,
    "fixed_schedule.json"
)


# ============================================================
# EDIT FIXED SCHEDULE
# ============================================================

def fixed_schedule_edit():

    if not os.path.exists(SCHOOL_SCHEDULE_FILE):

        print(
            "\n❌ Fixed schedule file not found."
        )

        return


    with open(
        SCHOOL_SCHEDULE_FILE,
        "r"
    ) as file:

        try:

            schedules = json.load(file)

        except json.JSONDecodeError:

            print(
                "\n❌ Fixed schedule file is corrupted."
            )

            return


    if not schedules:

        print(
            "\n❌ No fixed schedules available."
        )

        return


    print(
        Fore.CYAN
        + "\n╭────────────────────────────────────╮"
    )

    print(
        "│       EDIT FIXED SCHEDULE          │"
    )

    print(
        "├────────────────────────────────────┤"
    )


    for index, schedule in enumerate(
        schedules,
        start=1
    ):

        print(
            Fore.MAGENTA
            + f"│  [{index:02d}]  "
            f"{schedule['time']}  →  {schedule['name']}"
        )


    print(
        "╰────────────────────────────────────╯"
        + Style.RESET_ALL
    )


    while True:

        number = input(
            Fore.WHITE
            + "\n❯ Enter Event ID : "
        ).strip()


        if not number.isdigit():

            print(
                Fore.RED
                + "❌ Invalid ID."
                + Style.RESET_ALL
            )

            continue


        index = int(number) - 1


        if index < 0 or index >= len(schedules):

            print(
                Fore.RED
                + "❌ Event not found."
                + Style.RESET_ALL
            )

            continue


        schedule = schedules[index]


        print(
            Fore.YELLOW
            + "\n╭────────────────────────────────────╮"
        )

        print(
            Fore.MAGENTA
            + "│          CURRENT EVENT             │"
        )

        print(
            Fore.YELLOW
            + "├────────────────────────────────────┤"
        )


        print(
            Fore.RED
            + f"│ Name   : {schedule['name']}"
        )

        print(
            Fore.WHITE
            + f"│ Time   : {schedule['time']}"
        )

        print(
            Fore.RED
            + f"│ Status : {schedule['status']}"
        )


        print(
            Fore.YELLOW
            + "╰────────────────────────────────────╯"
        )


        new_name = input(
            Fore.GREEN
            + f"\n❯ New Name [{schedule['name']}] : "
        ).strip()


        new_time = input(
            Fore.GREEN
            + f"❯ New Time [{schedule['time']}] : "
        ).strip()


        print(
            Fore.YELLOW
            + "\n❯ Schedule Status"
        )

        print(
            Fore.GREEN
            + "[ 01 ] ENABLED"
        )

        print(
            Fore.RED
            + "[ 02 ] DISABLED"
            + Style.RESET_ALL
        )


        new_status = input(
            Fore.WHITE
            + f"❯ New Status [{schedule['status']}] : "
        ).strip()


        if new_name:

            schedule["name"] = new_name


        if new_time:

            schedule["time"] = new_time


        if new_status == "1":

            schedule["status"] = "ENABLED"

        elif new_status == "2":

            schedule["status"] = "DISABLED"


        with open(
            SCHOOL_SCHEDULE_FILE,
            "w"
        ) as file:

            json.dump(
                schedules,
                file,
                indent=4
            )


        print(
            Fore.GREEN
            + "\n✓ FIXED SCHEDULE UPDATED SUCCESSFULLY"
            + Style.RESET_ALL
        )


        time.sleep(2)

        os.system("cls")

        edit_schedule()

        break


# ============================================================
# EDIT SCHEDULE
# ============================================================

def edit_schedule():

    if not os.path.exists(SCHEDULE_FILE):

        print(
            "\n❌ No schedule found."
        )

        return


    with open(
        SCHEDULE_FILE,
        "r"
    ) as file:

        try:

            schedules = json.load(file)

        except json.JSONDecodeError:

            print(
                "\n❌ Schedule file is corrupted."
            )

            return


    if not schedules:

        print(
            "\n❌ No schedules available."
        )

        return


    print(
        Fore.CYAN
        + "\n╭────────────────────────────────────╮"
    )

    print(
        "│          EDIT SCHEDULE             │"
    )

    print(
        "├────────────────────────────────────┤"
    )


    for index, schedule in enumerate(
        schedules,
        start=1
    ):

        print(
            Fore.MAGENTA
            + f"│  [{index:02d}]  "
            f"{schedule['time']}  →  {schedule['name']}"
        )


    print(
        "╰────────────────────────────────────╯"
        + Style.RESET_ALL
    )


    print(
        Fore.YELLOW
        + "\n[ 01 ] EDIT EVENT"
    )

    print(
        Fore.RED
        + "[ 02 ] DELETE EVENT"
    )

    print(
        Fore.YELLOW
        + "[ 03 ] EDIT FIXED SCHEDULE"
    )

    print(
        Fore.YELLOW
        + "[ 04 ] BACK"
        + Style.RESET_ALL
    )


    # ========================================================
    # CHOOSE LOOP
    # ========================================================

    while True:

        choice = input(
            Fore.WHITE
            + "\n❯ Choose : "
        ).strip()

        print(Style.RESET_ALL)


        # ====================================================
        # EDIT EVENT
        # ====================================================

        if choice == "1":

            number = input(
                "❯ Enter Event ID : "
            ).strip()


            if not number.isdigit():

                print(
                    "❌ Invalid ID."
                )

                continue


            index = int(number) - 1


            if index < 0 or index >= len(schedules):

                print(
                    "❌ Event not found."
                )

                continue


            schedule = schedules[index]


            print(
                Fore.YELLOW
                + "\n╭────────────────────────────────────╮"
            )

            print(
                Fore.MAGENTA
                + "│          CURRENT EVENT             │"
            )

            print(
                Fore.YELLOW
                + "├────────────────────────────────────┤"
            )


            print(
                Fore.RED
                + f"│ Name : {schedule['name']}"
            )

            print(
                Fore.WHITE
                + f"│ Time : {schedule['time']}"
            )

            print(
                Fore.RED
                + f"│ Status : {schedule['status']}"
            )


            print(
                Fore.YELLOW
                + "╰────────────────────────────────────╯"
            )


            new_name = input(
                Fore.GREEN
                + f"\n❯ New Name [{schedule['name']}] : "
            ).strip()


            new_time = input(
                Fore.GREEN
                + f"❯ New Time [{schedule['time']}] : "
            ).strip()


            # =================================================
            # STATUS EDIT
            # =================================================

            print(
                Fore.YELLOW
                + "\n❯ Schedule Status"
            )

            print(
                Fore.GREEN
                + "[ 01 ] ENABLED"
            )

            print(
                Fore.RED
                + "[ 02 ] DISABLED"
                + Style.RESET_ALL
            )


            new_status = input(
                Fore.WHITE
                + f"❯ New Status [{schedule['status']}] : "
            ).strip()


            if new_name:

                schedule["name"] = new_name


            if new_time:

                schedule["time"] = new_time


            if new_status == "1":

                schedule["status"] = "ENABLED"

            elif new_status == "2":

                schedule["status"] = "DISABLED"


            with open(
                SCHEDULE_FILE,
                "w"
            ) as file:

                json.dump(
                    schedules,
                    file,
                    indent=4
                )


            print(
                Fore.GREEN
                + "\n✓ EVENT UPDATED SUCCESSFULLY"
                + Style.RESET_ALL
            )


            edit_schedule()

            break


        # ====================================================
        # DELETE EVENT
        # ====================================================

        elif choice == "2":

            print(
                Fore.YELLOW
                + "\n❯ Event ID means the number [01], [02], [03]..."
                + Style.RESET_ALL
            )


            number = input(
                "❯ Enter Event ID to delete : "
            ).strip()


            if not number.isdigit():

                print(
                    Fore.RED
                    + "❌ Invalid Event ID. Use numbers like 01, 02, 03..."
                    + Style.RESET_ALL
                )

                continue


            index = int(number) - 1


            if index < 0 or index >= len(schedules):

                print(
                    Fore.RED
                    + "❌ Event ID not found."
                    + Style.RESET_ALL
                )

                continue


            deleted = schedules.pop(index)


            with open(
                SCHEDULE_FILE,
                "w"
            ) as file:

                json.dump(
                    schedules,
                    file,
                    indent=4
                )


            print(
                Fore.GREEN
                + f"\n✓ DELETED : {deleted['name']} "
                  f"({deleted['time']})"
                + Style.RESET_ALL
            )


            time.sleep(2)

            os.system("cls")

            edit_schedule()

            break


        # ====================================================
        # EDIT FIXED SCHEDULE
        # ====================================================

        elif choice == "3":

            os.system("cls")

            fixed_schedule_edit()

            break


        # ====================================================
        # BACK
        # ====================================================

        elif choice == "4":

            print(
                Fore.CYAN
                + "\n↩ Returning..."
                + Style.RESET_ALL
            )


            qu = input(
                "press enter to continue menu ......"
            )


            time.sleep(2)

            os.system("cls")

            menu.menu_info()

            menu.choose()

            break


        # ====================================================
        # INVALID OPTION
        # ====================================================

        else:

            print(
                Fore.RED
                + "\n❌ Invalid option."
                + Style.RESET_ALL
            )


# ============================================================
# START PROGRAM
# ============================================================

if __name__ == "__main__":

    edit_schedule()