from datetime import datetime
from pathlib import Path
import os

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Font, PatternFill


# ============================================================
# PROJECT PATH
# ============================================================

BASE_DIR = Path(__file__).resolve().parent.parent

# ============================================================
# LOGS FOLDER
# ============================================================

LOGS_DIR = BASE_DIR / "logs"

LOG_FILE = LOGS_DIR / "daily_logs.xlsx"

TEXT_LOG_FILE = LOGS_DIR / "daily_logs.txt"

SHEET_NAME = "Daily Logs"


# ============================================================
# EXCEL HEADERS
# ============================================================

HEADERS = [
    "Date",
    "Time",
    "Category",
    "Action",
    "Details"
]


# ============================================================
# CLEAN VALUE
# ============================================================

def _clean(value):

    if value is None:
        return ""

    return " ".join(
        str(value)
        .replace("|", "/")
        .replace("\n", " ")
        .replace("\r", " ")
        .split()
    )


# ============================================================
# STYLE EXCEL SHEET
# ============================================================

def _style_sheet(sheet):

    sheet.freeze_panes = "A2"

    sheet.auto_filter.ref = sheet.dimensions

    widths = {
        "A": 14,
        "B": 12,
        "C": 18,
        "D": 32,
        "E": 70
    }

    for column, width in widths.items():

        sheet.column_dimensions[column].width = width


    # ========================================================
    # HEADER STYLE
    # ========================================================

    for cell in sheet[1]:

        cell.font = Font(
            bold=True,
            color="FFFFFF"
        )

        cell.fill = PatternFill(
            fill_type="solid",
            fgColor="1F4E78"
        )

        cell.alignment = Alignment(
            horizontal="center",
            vertical="center"
        )


    # ========================================================
    # DATA STYLE
    # ========================================================

    for row in sheet.iter_rows(
        min_row=2
    ):

        # DATE
        row[0].number_format = "yyyy-mm-dd"

        row[0].alignment = Alignment(
            horizontal="center",
            vertical="center"
        )


        # TIME
        row[1].number_format = "hh:mm:ss"

        row[1].alignment = Alignment(
            horizontal="center",
            vertical="center"
        )


        # CATEGORY
        row[2].alignment = Alignment(
            horizontal="center",
            vertical="center"
        )


        # ACTION
        row[3].alignment = Alignment(
            vertical="top"
        )


        # DETAILS
        row[4].alignment = Alignment(
            wrap_text=True,
            vertical="top"
        )


# ============================================================
# GET WORKBOOK
# ============================================================

def _get_workbook():

    # --------------------------------------------------------
    # CREATE LOGS FOLDER
    # --------------------------------------------------------

    LOGS_DIR.mkdir(
        parents=True,
        exist_ok=True
    )


    # --------------------------------------------------------
    # CREATE NEW EXCEL FILE
    # --------------------------------------------------------

    if not LOG_FILE.exists():

        workbook = Workbook()

        sheet = workbook.active

        sheet.title = SHEET_NAME

        sheet.append(HEADERS)

        _style_sheet(sheet)

        workbook.save(LOG_FILE)

        return workbook


    # --------------------------------------------------------
    # LOAD EXISTING EXCEL FILE
    # --------------------------------------------------------

    workbook = load_workbook(
        LOG_FILE
    )


    # --------------------------------------------------------
    # CREATE SHEET IF MISSING
    # --------------------------------------------------------

    if SHEET_NAME not in workbook.sheetnames:

        sheet = workbook.create_sheet(
            SHEET_NAME
        )

        sheet.append(HEADERS)

        _style_sheet(sheet)

        workbook.save(LOG_FILE)


    return workbook


# ============================================================
# WRITE TEXT LOG
# ============================================================

def _write_text_log(
    date_text,
    time_text,
    category,
    action,
    details
):

    # --------------------------------------------------------
    # CREATE LOGS FOLDER
    # --------------------------------------------------------

    LOGS_DIR.mkdir(
        parents=True,
        exist_ok=True
    )


    # --------------------------------------------------------
    # OPEN TXT FILE
    # --------------------------------------------------------

    with open(
        TEXT_LOG_FILE,
        "a",
        encoding="utf-8"
    ) as file:

        file.write(
            "============================================================\n"
        )

        file.write(
            f"DATE     : {date_text}\n"
        )

        file.write(
            f"TIME     : {time_text}\n"
        )

        file.write(
            f"CATEGORY : {category}\n"
        )

        file.write(
            f"ACTION   : {action}\n"
        )

        if details:

            file.write(
                f"DETAILS  : {details}\n"
            )

        file.write(
            "============================================================\n\n"
        )


# ============================================================
# LOG EVENT
# ============================================================

def log_event(
    category,
    action,
    details=""
):

    timestamp = datetime.now()


    # --------------------------------------------------------
    # FORMAT DATE AND TIME
    # --------------------------------------------------------

    date_text = timestamp.strftime(
        "%Y-%m-%d"
    )

    time_text = timestamp.strftime(
        "%H:%M:%S"
    )


    # --------------------------------------------------------
    # CLEAN VALUES
    # --------------------------------------------------------

    category = _clean(
        category
    )

    action = _clean(
        action
    )

    details = _clean(
        details
    )


    # ========================================================
    # SAVE TO EXCEL
    # ========================================================

    workbook = _get_workbook()

    sheet = workbook[SHEET_NAME]


    sheet.append(
        [
            timestamp.date(),

            timestamp.time().replace(
                microsecond=0
            ),

            category,

            action,

            details
        ]
    )


    _style_sheet(
        sheet
    )


    workbook.save(
        LOG_FILE
    )


    # ========================================================
    # SAVE TO TXT
    # ========================================================

    _write_text_log(
        date_text,
        time_text,
        category,
        action,
        details
    )


# ============================================================
# COMPATIBILITY FUNCTION
# ============================================================
#
# Existing main.py calls such as:
#
# save_log("SCHEDULE SYSTEM STARTED")
#
# can continue working.
#
# ============================================================

def save_log(message):

    message = _clean(
        message
    )

    upper_message = message.upper()


    # ========================================================
    # DETECT CATEGORY
    # ========================================================

    if "BLUETOOTH" in upper_message:

        category = "BLUETOOTH"

    elif "SCHEDULE" in upper_message:

        category = "SCHEDULE"

    elif "MENU" in upper_message:

        category = "MENU"

    elif "BELL" in upper_message:

        category = "BELL"

    elif (
        "ERROR" in upper_message
        or "FAILED" in upper_message
        or "INVALID" in upper_message
    ):

        category = "ERROR"

    else:

        category = "SYSTEM"


    # ========================================================
    # ACTION
    # ========================================================

    action = message

    details = ""


    # ========================================================
    # SAVE
    # ========================================================

    log_event(
        category,
        action,
        details
    )


# ============================================================
# SHOW LOGS
# ============================================================

def show_logs():

    # --------------------------------------------------------
    # EXCEL FILE CHECK
    # --------------------------------------------------------

    if LOG_FILE.exists():

        print(
            f"\n📊 Excel Log : {LOG_FILE}"
        )

    else:

        print(
            "\n❌ No Excel log file found."
        )


    # --------------------------------------------------------
    # TXT FILE CHECK
    # --------------------------------------------------------

    if TEXT_LOG_FILE.exists():

        print(
            f"📝 Text Log  : {TEXT_LOG_FILE}"
        )

    else:

        print(
            "❌ No text log file found."
        )


    # ========================================================
    # OPEN EXCEL
    # ========================================================

    if LOG_FILE.exists():

        try:

            os.startfile(
                LOG_FILE
            )

        except OSError as error:

            print(
                "\n⚠ Could not open Excel automatically."
            )

            print(
                f"Reason: {error}"
            )


# ============================================================
# CLEAR LOGS
# ============================================================

def clear_logs():

    # ========================================================
    # DELETE EXCEL LOG
    # ========================================================

    if LOG_FILE.exists():

        try:

            LOG_FILE.unlink()

        except PermissionError:

            print(
                "\n❌ Cannot clear logs."
            )

            print(
                "Please close daily_logs.xlsx "
                "and try again."
            )

            return


    # ========================================================
    # DELETE TXT LOG
    # ========================================================

    if TEXT_LOG_FILE.exists():

        try:

            TEXT_LOG_FILE.unlink()

        except PermissionError:

            print(
                "\n❌ Cannot clear logs."
            )

            print(
                "Please close daily_logs.txt "
                "and try again."
            )

            return


    # ========================================================
    # CREATE FRESH EXCEL FILE
    # ========================================================

    workbook = Workbook()

    sheet = workbook.active

    sheet.title = SHEET_NAME

    sheet.append(
        HEADERS
    )

    _style_sheet(
        sheet
    )


    # --------------------------------------------------------
    # MAKE SURE LOGS FOLDER EXISTS
    # --------------------------------------------------------

    LOGS_DIR.mkdir(
        parents=True,
        exist_ok=True
    )


    workbook.save(
        LOG_FILE
    )


    # ========================================================
    # CREATE FIRST TXT ENTRY
    # ========================================================

    now = datetime.now()

    _write_text_log(
        now.strftime("%Y-%m-%d"),
        now.strftime("%H:%M:%S"),
        "SYSTEM",
        "Log file cleared",
        "A new daily log was started"
    )


    print(
        "\n✓ Excel and TXT logs cleared successfully."
    )