
from colorama import Style, Fore, init
import time
from modules import addschedule
from modules import view
from modules import edit
import os
from modules import start_sch


init()

sy = Fore.GREEN + ("●")


def menu_info():

    menu = r"""
╭──────────────────────────────────────────╮
│                                          │
│  ███╗   ███╗ ███████╗ ███╗   ██╗ ██╗   ██╗
│  ████╗ ████║ ██╔════╝ ████╗  ██║ ██║   ██║
│  ██╔████╔██║ █████╗   ██╔██╗ ██║ ██╗   ██║
│  ██║╚██╔╝██║ ██╔══╝   ██║╚██╗██║ ██║   ██║
│  ██║ ╚═╝ ██║ ███████╗ ██║ ╚████║ ╚██████╔╝
  ╚═╝     ╚═╝ ╚══════╝ ╚═╝  ╚═══╝  ╚═════╝
│                                          │
            ⚡ SYSTEM CONSOLE ⚡        │
├──────────────────────────────────────────┤
│                                          │
│   [ 01 ]  ◈  ADD SCHEDULE                │
│   [ 02 ]  ◈  VIEW SCHEDULE               │
│   [ 03 ]  ◈  EDIT SCHEDULE               │
│   [ 04 ]  ◈  START SCHEDULE              │
│   [ 05 ]  ◈  EXIT                        │
│                                          │
├──────────────────────────────────────────┤
│   STATUS : ● ONLINE                      │
│   MODE   : SYSTEM READY                  │
│                                          │
╰──────────────────────────────────────────╯
"""

    try:
        terminal_width = os.get_terminal_size().columns
    except OSError:
        terminal_width = 80

    lines = menu.strip("\n").splitlines()

    for line in lines:

        line = line.rstrip()

        padding = max(
            0,
            (terminal_width - len(line)) // 2
        )

        # ------------------------------------------------
        # Default WHITE
        # ------------------------------------------------

        color = Fore.WHITE

        # ------------------------------------------------
        # MAGENTA - LOGO
        # ------------------------------------------------

        if (
            "███╗" in line
            or "████╗" in line
            or "██╔" in line
            or "██║" in line
            or "╚═" in line
        ):
            color = Fore.MAGENTA

        # ------------------------------------------------
        # YELLOW - SYSTEM CONSOLE / MENU TEXT
        # ------------------------------------------------

        if "SYSTEM CONSOLE" in line:
            color = Fore.YELLOW

        if (
            "ADD SCHEDULE" in line
            or "VIEW SCHEDULE" in line
            or "EDIT SCHEDULE" in line
            or "START SCHEDULE" in line
            or "EXIT" in line
        ):
            color = Fore.YELLOW

        # ------------------------------------------------
        # RED - MENU NUMBERS
        # ------------------------------------------------

        if "[ 01 ]" in line or "[ 02 ]" in line:
            color = Fore.RED

        if "[ 03 ]" in line or "[ 04 ]" in line:
            color = Fore.RED

        if "[ 05 ]" in line:
            color = Fore.RED

        # ------------------------------------------------
        # GREEN - ONLINE
        # ------------------------------------------------

        if "ONLINE" in line:
            color = Fore.GREEN

        # ------------------------------------------------
        # RED - SYSTEM READY
        # ------------------------------------------------

        if "SYSTEM READY" in line:
            color = Fore.RED

        print(
            " " * padding
            + color
            + line
            + Style.RESET_ALL
        )


def choose():

    while True:

        ask2 = input(
            Fore.WHITE
            + "❯ CHOOSE OPTION :"
        )

        sbybol = Fore.RED + "+>"

        status = Fore.GREEN + "● ONLINE"

        if ask2 == "1":

            print(
                Fore.GREEN
                + "SCHEDULE ADD FUN() IS START .........."
            )

            time.sleep(2)

            print(
                sbybol
                + "status : "
                + status
            )

            time.sleep(2)

            os.system("cls")

            addschedule.add_schedule()

            break

        elif ask2 == "2":

            print(
                Fore.GREEN
                + "SCHEDULE VIEW FUN() IS START NOW ........"
            )

            time.sleep(2)

            print(
                sbybol
                + "status : "
                + status
            )

            time.sleep(2)

            os.system("cls")

            view.view_schedule()

            break

        elif ask2 == "3":

            print(
                Fore.GREEN
                + "SCHEDULE EDIT FUN() IS START NOW ........"
            )

            time.sleep(2)

            print(
                sbybol
                + "status : "
                + status
            )

            time.sleep(2)

            os.system("cls")

            edit.edit_schedule()

            break

        elif ask2 == "4":

            print(
                Fore.GREEN
                + "SCHEDULE START FUN() IS START NOW ........."
            )

            time.sleep(2)

            print(
                sbybol
                + "status : "
                + status
            )

            time.sleep(2)

            os.system("cls")

            start_sch.start_schedule()

            break

        elif ask2 == "5":

            print("EXIT THE MENU")

            time.sleep(2)

            print(
                sy
                + Fore.RED
                + " OFFLINE"
            )

            time.sleep(2)

            input(
                "press enter to exit the [MENU] ......"
            )

            os.system("cls")

            break

        else:

            print(
                "PLEASE SELECT THE CORRECT OPTION [1,2,3..] ?"
            )


if __name__ == "__main__":

    menu_info()
    choose()
