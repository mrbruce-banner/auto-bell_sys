import json
import os
import time
from datetime import datetime

from colorama import Fore, Style, init

from modules import menu
from modules import bell


init()


SCHEDULE_FILE = os.path.join(
    os.path.dirname(
        os.path.dirname(
            os.path.abspath(__file__)
        )
    ),
    "cookies",
    "schedules.json"
)


SCHOOL_SCHEDULE_FILE = os.path.join(
    os.path.dirname(
        os.path.dirname(
            os.path.abspath(__file__)
        )
    ),
    "cookies",
    "fixed_schedule.json"
)


# ============================================================
# LOAD SCHEDULE
# ============================================================

def load_schedule(file_name):

    if not os.path.exists(file_name):

        print(
            Fore.RED
            + f"\n❌ File not found : {file_name}"
            + Style.RESET_ALL
        )

        return None


    try:

        with open(file_name, "r") as file:

            schedules = json.load(file)


    except json.JSONDecodeError:

        print(
            Fore.RED
            + f"\n❌ {file_name} is corrupted."
            + Style.RESET_ALL
        )

        return None


    if not schedules:

        print(
            Fore.YELLOW
            + f"\n⚠ {file_name} is empty."
            + Style.RESET_ALL
        )

        return None


    return schedules


# ============================================================
# RUN SCHEDULE
# ============================================================

def run_schedule(schedules, schedule_name):

    print(
        Fore.GREEN
        + f"\n✓ {schedule_name} SELECTED"
        + Style.RESET_ALL
    )


    # =================================
    # SHOW SCHEDULE LIST
    # =================================

    print(
        Fore.CYAN
        + "\n╭────────────────────────────────────────────╮"
    )

    print(
        "│              SCHEDULE LIST                 │"
    )

    print(
        "├────────────────────────────────────────────┤"
    )


    for index, schedule in enumerate(
        schedules,
        start=1
    ):

        print(
            f"│ [{index:02d}] "
            f"{schedule['time']}  →  "
            f"{schedule['name']}"
        )


    print(
        "╰────────────────────────────────────────────╯"
        + Style.RESET_ALL
    )


    now = datetime.now()

    upcoming_events = []


    # =================================
    # CHECK EVERY EVENT
    # =================================

    for schedule in schedules:

        event_name = schedule["name"]

        event_time_text = schedule["time"]

        status = schedule.get(
            "status",
            "ENABLED"
        ).upper()


        # =================================
        # DISABLED EVENT
        # =================================

        if status != "ENABLED":

            print(
                Fore.YELLOW
                + f"\n⚠ {event_name} → SKIPPED"
                + Fore.WHITE
                + " | Reason: Event is disabled."
                + Style.RESET_ALL
            )

            continue


        # =================================
        # CONVERT EVENT TIME
        # =================================

        try:

            event_time = datetime.strptime(
                event_time_text.strip().upper(),
                "%I:%M %p"
            )


            event_time = event_time.replace(
                year=now.year,
                month=now.month,
                day=now.day
            )


        except ValueError:

            print(
                Fore.RED
                + f"\n❌ {event_name} → SKIPPED"
                + Fore.WHITE
                + f" | Reason: Invalid time {event_time_text}"
                + Style.RESET_ALL
            )

            continue


        # =================================
        # TIME ALREADY PASSED
        # =================================

        if event_time < now:

            print(
                Fore.YELLOW
                + f"\n⚠ {event_name} → SKIPPED"
                + Fore.WHITE
                + Fore.RED
                + " | Reason: Event time is up."
                + Style.RESET_ALL
            )

            continue


        # =================================
        # FUTURE EVENT
        # =================================

        upcoming_events.append(
            (event_time, schedule)
        )


    # =================================
    # SORT EVENTS
    # =================================

    upcoming_events.sort(
        key=lambda event: event[0]
    )


    # =================================
    # NO UPCOMING EVENTS
    # =================================

    if not upcoming_events:

        print(
            Fore.CYAN
            + "\n✓ No upcoming events for today."
            + Style.RESET_ALL
        )

        time.sleep(2)

        input(
            Fore.WHITE
            + "press enter to exit ........"
        )

        os.system("cls")

        start_schedule()

        return


    print(
        Fore.GREEN
        + "\n✓ Upcoming events loaded."
        + Style.RESET_ALL
    )


    # =================================
    # EVENT LOOP
    # =================================

    for event_time, schedule in upcoming_events:

        event_name = schedule["name"]


        print(
            Fore.YELLOW
            + f"\n⏳ Waiting for : {event_name}"
            + Fore.WHITE
            + f" [{schedule['time']}]"
            + Style.RESET_ALL
        )


        while True:

            # =================================================
            # CTRL + C HANDLING
            # =================================================
            #
            # IMPORTANT:
            # Ctrl+C here will ONLY cancel the running
            # schedule.
            #
            # It will NOT close the complete application.
            #
            # =================================================

            try:

                now = datetime.now()

                current_time = now.strftime(
                    "%I:%M:%S %p"
                )


                print(
                    f"\rCURRENT TIME : {current_time}",
                    end="",
                    flush=True
                )


                # =================================
                # EVENT TIME REACHED
                # =================================

                if now >= event_time:

                    print(
                        Fore.GREEN
                        + f"\n\n🔔 EVENT STARTED : {event_name}"
                        + Style.RESET_ALL
                    )


                    print(
                        Fore.CYAN
                        + "🔊 PLAYING SCHOOL BELL..."
                        + Style.RESET_ALL
                    )


                    # =================================
                    # CALL BELL FUNCTION
                    # =================================

                    bell.bell_fun()


                    time.sleep(2)

                    os.system("cls")

                    start_schedule()

                    return


                time.sleep(1)


            # =================================================
            # CTRL + C
            # =================================================

            except KeyboardInterrupt:

                print(
                    Fore.YELLOW
                    + "\n\n⚠ SCHEDULE CANCELLED BY USER."
                    + Style.RESET_ALL
                )


                time.sleep(1)

                os.system("cls")


                # =============================================
                # RETURN TO START SCHEDULE INTERFACE
                # =============================================

                start_schedule()

                return


    # =================================
    # FINISHED
    # =================================

    print(
        Fore.CYAN
        + "\n\n✓ ALL UPCOMING EVENTS COMPLETED."
        + Style.RESET_ALL
    )


# ============================================================
# START SCHEDULE
# ============================================================

def start_schedule():

    print(
        Fore.CYAN
        + "\n╭────────────────────────────────────╮"
    )

    print(
        Fore.GREEN
        + "│          START SCHEDULE            │"
    )

    print(
        Fore.WHITE
        + "├────────────────────────────────────┤"
    )

    print(
        Fore.MAGENTA
        + "│  [01] MY SCHEDULE                  │"
    )

    print(
        Fore.MAGENTA
        + "│  [02] FIXED SCHEDULE               │"
    )

    print(
        Fore.MAGENTA
        + "│  [03] BACK                         │"
    )

    print(
        Fore.WHITE
        + "╰────────────────────────────────────╯"
        + Style.RESET_ALL
    )


    while True:

        choice = input(
            Fore.WHITE
            + "\n❯ Choose : "
        ).strip()


        print(
            Style.RESET_ALL
        )


        # =================================
        # MY SCHEDULE
        # =================================

        if choice == "1":

            schedules = load_schedule(
                SCHEDULE_FILE
            )


            if schedules is not None:

                run_schedule(
                    schedules,
                    "MY SCHEDULE"
                )

                break


        # =================================
        # SCHOOL SCHEDULE
        # =================================

        elif choice == "2":

            schedules = load_schedule(
                SCHOOL_SCHEDULE_FILE
            )


            if schedules is not None:

                run_schedule(
                    schedules,
                    "SCHOOL SCHEDULE"
                )


                time.sleep(2)


                input(
                    "press enter to exit ....."
                )


                os.system("cls")

                start_schedule()

                break


        # =================================
        # BACK
        # =================================

        elif choice == "3":

            print(
                Fore.CYAN
                + "\n↩ Returning..."
                + Style.RESET_ALL
            )


            time.sleep(2)

            time.sleep(1)

            os.system("cls")


            menu.menu_info()

            menu.choose()

            break


        # =================================
        # INVALID OPTION
        # =================================

        else:

            print(
                Fore.RED
                + "\n❌ Invalid option."
                + Style.RESET_ALL
            )


# ============================================================
# START PROGRAM
# ============================================================

if __name__ == "__main__":

    start_schedule()