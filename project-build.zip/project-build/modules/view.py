import json
import os
from colorama import Style, Fore, init
import time
from modules import menu


init(autoreset=True)


# ============================================================
# PROJECT PATH
# ============================================================

BASE_DIR = os.path.dirname(
    os.path.dirname(
        os.path.abspath(__file__)
    )
)

COOKIES_DIR = os.path.join(
    BASE_DIR,
    "cookies"
)


SCHEDULE_FILE = os.path.join(
    COOKIES_DIR,
    "schedules.json"
)

SCHOOL_SCHEDULE_FILE = os.path.join(
    COOKIES_DIR,
    "fixed_schedule.json"
)


def get_status_color(status):

    status = str(status).strip().upper()

    if status in ("DISABLE", "DISABLED"):

        return Fore.RED

    return Fore.GREEN


def view_schedule():

    if not os.path.exists(SCHEDULE_FILE):

        print(
            Fore.RED
            + "\n❌ No schedule found."
            + Style.RESET_ALL
        )

        return

    with open(SCHEDULE_FILE, "r") as file:

        try:

            schedules = json.load(file)

        except json.JSONDecodeError:

            print(
                Fore.RED
                + "\n❌ Schedule file is corrupted."
                + Style.RESET_ALL
            )

            return

    if not schedules:

        print(
            Fore.RED
            + "\n❌ No schedule available."
            + Style.RESET_ALL
        )

        return


    # ========================================================
    # SCHEDULE VIEW
    # ========================================================

    print(
        Fore.CYAN
        + """
╭────────────────────────────────────────────────────────────╮
│                    📅 SCHEDULE VIEW                        │
├────────┬──────────────────────┬────────────┬───────────────┤
│   ID   │       SCHEDULE       │    TIME    │    STATUS     │
├────────┼──────────────────────┼────────────┼───────────────┤
"""
        + Style.RESET_ALL
    )


    # ========================================================
    # USER SCHEDULE
    # ========================================================

    for index, schedule in enumerate(schedules, start=1):

        status = str(
            schedule.get("status", "")
        ).strip()

        status_color = get_status_color(status)

        print(
            Fore.WHITE
            + "│  "
            + Fore.RED
            + f"{index:02d}"
            + Fore.WHITE
            + "    │  "
            + Fore.YELLOW
            + f"{schedule.get('name', ''):<20}"
            + Fore.WHITE
            + "│  "
            + Fore.YELLOW
            + f"{schedule.get('time', ''):<10}"
            + Fore.WHITE
            + "│  "
            + status_color
            + f"{status:<13}"
            + Fore.WHITE
            + "│"
            + Style.RESET_ALL
        )


    # ========================================================
    # FIXED BELL
    # ========================================================

    print(
        Fore.CYAN
        + """├────────┴──────────────────────┴────────────┴───────────────┤
│                    🔔 FIXED BELL : ON                      │
╰────────────────────────────────────────────────────────────╯
"""
        + Style.RESET_ALL
    )


    # ========================================================
    # FIXED SCHOOL SCHEDULE
    # ========================================================

    if os.path.exists(SCHOOL_SCHEDULE_FILE):

        with open(SCHOOL_SCHEDULE_FILE, "r") as file:

            try:

                school_schedules = json.load(file)

            except json.JSONDecodeError:

                print(
                    Fore.RED
                    + "\n❌ School schedule file is corrupted."
                    + Style.RESET_ALL
                )

                return


        if school_schedules:

            print(
                Fore.CYAN
                + """
╭────────────────────────────────────────────────────────────╮
│                 🏫 FIXED SCHOOL SCHEDULE                   │
├────────┬──────────────────────┬────────────┬───────────────┤
│   ID   │       SCHEDULE       │    TIME    │    STATUS     │
├────────┼──────────────────────┼────────────┼───────────────┤
"""
                + Style.RESET_ALL
            )


            # =================================================
            # FIXED SCHOOL SCHEDULE LIST
            # =================================================

            for index, schedule in enumerate(
                school_schedules,
                start=1
            ):

                status = str(
                    schedule.get("status", "")
                ).strip()

                status_color = get_status_color(status)

                print(
                    Fore.WHITE
                    + "│  "
                    + Fore.RED
                    + f"{index:02d}"
                    + Fore.WHITE
                    + "    │  "
                    + Fore.YELLOW
                    + f"{schedule.get('name', ''):<20}"
                    + Fore.WHITE
                    + "│  "
                    + Fore.YELLOW
                    + f"{schedule.get('time', ''):<10}"
                    + Fore.WHITE
                    + "│  "
                    + status_color
                    + f"{status:<13}"
                    + Fore.WHITE
                    + "│"
                    + Style.RESET_ALL
                )


            print(
                Fore.CYAN
                + """
╰────────┴──────────────────────┴────────────┴───────────────╯
"""
                + Style.RESET_ALL
            )


    # ========================================================
    # RETURN TO MENU
    # ========================================================

    time.sleep(2)

    qu = input(
        "press enter to continue menu ......."
    )

    os.system("cls")

    menu.menu_info()

    menu.choose()


# ============================================================
# RUN
# ============================================================

if __name__ == "__main__":

    view_schedule()